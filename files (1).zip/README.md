# 🤖 Multi-Domain Support Triage Agent

A terminal-based AI support triage agent that classifies and responds to support tickets
across **HackerRank**, **Claude (Anthropic)**, and **Visa** — using a curated support corpus
and the Claude API. No external packages required.

---

## 📁 Repo Structure

```
support-triage-agent/
├── agent.py                  # Main agent (single file, stdlib only)
├── support_issues.csv        # Your input file (fill this in)
├── sample_support_issues.csv # Labeled examples showing expected format
├── sample_triage_output.csv  # Example output so you know what to expect
├── .gitignore                # Excludes keys, outputs, caches
└── README.md                 # This file
```

---

## ⚙️ Setup

**Requirements:** Python 3.8+ · No pip installs needed

### 1. Clone the repo

```bash
git clone https://github.com/YOUR_USERNAME/support-triage-agent.git
cd support-triage-agent
```

### 2. Set your API key

```bash
export ANTHROPIC_API_KEY="sk-ant-..."
```

> ⚠️ Never hardcode your key in any file. Use environment variables only.

---

## 🚀 Usage

### Process a CSV file

```bash
python agent.py --input support_issues.csv --output triage_output.csv
```

With the sample reference file:
```bash
python agent.py \
  --input support_issues.csv \
  --output triage_output.csv \
  --sample sample_support_issues.csv
```

### Interactive single-ticket mode

```bash
python agent.py --interactive
```

### Save a full terminal transcript

```bash
python agent.py --input support_issues.csv --output triage_output.csv 2>&1 | tee transcript.txt
```

This saves everything printed to the terminal into `transcript.txt` while still showing it live.

### All options

| Flag | Default | Description |
|---|---|---|
| `--input / -i` | — | Input CSV path |
| `--output / -o` | `triage_output.csv` | Output CSV path |
| `--sample / -s` | — | Sample CSV (for format reference) |
| `--interactive` | off | Single-ticket interactive mode |
| `--delay` | `0.5` | Seconds between API calls (rate-limit buffer) |
| `--verbose` | off | Extra debug output |

---

## 📥 Input CSV Schema

| Field | Required | Notes |
|---|---|---|
| `issue` | ✅ | Main ticket body |
| `subject` | ❌ | May be blank, noisy, or misleading |
| `company` | ✅ | `HackerRank`, `Claude`, `Visa`, or `None` |

---

## 📤 Output CSV Schema

Every input row gets these 5 fields appended:

| Field | Values | Meaning |
|---|---|---|
| `status` | `replied` \| `escalated` | Whether agent answered or needs human |
| `product_area` | e.g. `card_fraud`, `billing_subscription` | Classified domain area |
| `response` | String | User-facing message grounded in corpus |
| `justification` | String | Internal reasoning for the decision |
| `request_type` | `product_issue` \| `feature_request` \| `bug` \| `invalid` | Ticket classification |

See `sample_triage_output.csv` for a fully worked example across all 3 companies.

---

## 🏗️ Architecture

```
support_issues.csv
       │
       ▼
┌──────────────────────────────────────┐
│  Pre-flight Safety Checks (no LLM)   │
│  ├─ Prompt injection / manipulation? │
│  └─ High-risk keywords?              │
│     (fraud, hack, legal, stolen…)    │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Corpus Retrieval                     │
│  ├─ Filter by company field           │
│  └─ Score & rank relevant snippets   │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Claude API (claude-sonnet-4)         │
│  System: strict JSON-only prompt      │
│  User:   ticket + corpus + risk hint  │
└──────────────┬───────────────────────┘
               │
               ▼
    triage_output.csv  +  transcript.txt
```

---

## 🛡️ Safety Features

1. **Prompt injection detection** — pattern-matched before the LLM sees the ticket; classifies as `invalid` and escalates
2. **Risk keyword escalation** — fraud, legal threats, account compromise → always escalated regardless of LLM output
3. **Corpus-grounded responses** — LLM is instructed to never invent policies; only embedded corpus content is used
4. **Graceful API failure** — errors produce a safe escalation response, never a crash
5. **Company inference** — when `company=None`, the LLM infers from ticket content

---

## 🐙 Putting This on GitHub

### First time

```bash
# Inside the project folder
git init
git add .
git commit -m "Initial commit: support triage agent"

# Create a new repo on github.com (don't initialize with README), then:
git remote add origin https://github.com/YOUR_USERNAME/support-triage-agent.git
git branch -M main
git push -u origin main
```

### Updating later

```bash
git add .
git commit -m "your message here"
git push
```

### What gets committed vs ignored

| File | Committed? | Why |
|---|---|---|
| `agent.py` | ✅ Yes | Source code |
| `README.md` | ✅ Yes | Documentation |
| `sample_support_issues.csv` | ✅ Yes | Reference examples |
| `sample_triage_output.csv` | ✅ Yes | Example output |
| `support_issues.csv` | ✅ Yes | Input template |
| `triage_output.csv` | ❌ No | Generated output, in `.gitignore` |
| `transcript.txt` | ❌ No | Generated log, in `.gitignore` |
| `.env` / API key files | ❌ No | Secrets, in `.gitignore` |

---

## 📝 Notes

- Never commit your `ANTHROPIC_API_KEY` — use `export` in your shell
- To extend the corpus, edit the `CORPUS` dict in `agent.py`
- `triage_output.csv` and `transcript.txt` are intentionally gitignored — they're run artifacts
